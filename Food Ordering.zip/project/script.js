// script.js

// Menu items data
const menu = [
    { id: 1, name: "Burger", description: "Delicious grilled burger", price: 5.99, image: "burger.jpg" },
    { id: 2, name: "Pizza", description: "Cheesy and delightful", price: 8.99, image: "pizza.jpg" },
    { id: 3, name: "Pasta", description: "Creamy and savory", price: 7.49, image: "pasta.jpg" },
  ];
  
  let cart = [];
  
  // Render menu items
  const menuContainer = document.getElementById("menu-items");
  
  menu.forEach((item) => {
    const menuItem = document.createElement("div");
    menuItem.classList.add("menu-item");
    menuItem.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <div class="item-info">
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <span>$${item.price.toFixed(2)}</span>
        <button onclick="addToCart(${item.id})">Add to Cart</button>
      </div>
    `;
    menuContainer.appendChild(menuItem);
  });
  
  // Add item to cart
  function addToCart(itemId) {
    const item = menu.find((menuItem) => menuItem.id === itemId);
    cart.push(item);
    renderCart();
  }
  
  // Render cart
  const cartContainer = document.getElementById("cart-items");
  const totalPriceElement = document.getElementById("total-price");
  
  function renderCart() {
    cartContainer.innerHTML = "";
    let total = 0;
  
    cart.forEach((item) => {
      const cartItem = document.createElement("li");
      cartItem.innerHTML = `
        <span>${item.name}</span>
        <span>$${item.price.toFixed(2)}</span>
      `;
      cartContainer.appendChild(cartItem);
      total += item.price;
    });
  
    totalPriceElement.textContent = Total: $${total.toFixed(2)};
  }